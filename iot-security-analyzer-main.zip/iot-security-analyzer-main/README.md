# iot-security-analyzer
The The IoT Security Analyzer is a tool designed to assess and enhance the security of Internet of Things (IoT) 
devices. The RPL Attack Detection System is designed to simulate and analyze security threats in IoT networks 
using the RPL protocol in Contiki-NG. As IoT networks grow, they face increasing threats from routing-based 
attacks. This project focuses on simulating RPL attacks and detecting them through IDS logic embedded in
the RPL server node.
# RPL-Based Attack Detection in Contiki-NG Using IDS

## Overview

This project simulates a secure IoT network in the **Contiki-NG** operating system using **Cooja**. It demonstrates how an **Intrusion Detection System (IDS)** can detect various **RPL-based routing and application-layer attacks** in a 6LoWPAN network. The IDS logic is embedded in a central UDP server node (`rplserver`) that monitors network traffic from multiple client nodes.

## Objective

To implement and evaluate a lightweight, rule-based IDS capable of detecting:
- **Blackhole attacks** (dropping packets)
- **Flooding attacks** (sending excessive packets)
- **Replay attacks** (sending old packets)
- **Normal behavior** (for comparison)

## Simulation Setup

- **Network Type**: RPL-based 6LoWPAN
- **Simulation Tool**: Cooja (part of Contiki-NG)
- **Node Roles**:
  - **`rplclient.c`** – Normal UDP client
  - **`rplblackhole.c`** – Drops all packets (Blackhole Attacker)
  - **`rplflood.c`** – Sends packets at high frequency (Flooding Attacker)
  - **`rplreplay.c`** – Repeats old packets (Replay Attacker)
  - **`rplserver.c`** – IDS-enabled UDP Server (detection logic)

## How It Works

1. All clients send UDP packets to the `rplserver` node.
2. The server inspects traffic patterns such as:
   - Packet frequency
   - Repeated content
   - Missing packets
3. Based on thresholds and behavior, the IDS detects anomalies and classifies nodes as **malicious** or **normal**.

## Key Features

- Simulates three distinct RPL-based attacks.
- Lightweight IDS suitable for constrained IoT nodes.
- Real-time detection via server console outputs.
- Helps analyze behavioral patterns for each type of attack.

## Use Cases

- IoT security research
- Academic demonstration of RPL attacks and defenses
- Testing IDS strategies for low-power networks

## Requirements

- Contiki-NG (with Cooja simulator)
- Java (for running Cooja)
- Basic knowledge of C programming and network protocols (RPL, UDP)

---
## Contributors

- [Bhavyasingh2006](https://github.com/Bhavyasingh2006)
- [monu20050608](https://github.com/monu20050608)
- [Aayush6282](https://github.com/Aayush6282)
- [Gourank2000](https://github.com/Gourank2000)
- [devendrayadv](https://github.com/devendrayadv)

---
## Mentor
Mr. Prakash Meena Sir
